// Cubeland — оригинальная воксельная песочница на чистом Rust (только std).
// Рендер: raycasting (DDA) прямо в терминал, truecolor + символ '▀' (2 пикселя на ячейку).

use std::collections::VecDeque;
use std::f32::consts::TAU;
use std::fmt::Write as FmtWrite;
use std::io::{self, Read, Write};
use std::process::{Command, Stdio};
use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};

const SX: usize = 96;
const SY: usize = 40;
const SZ: usize = 96;
const SEA: i32 = 10;
const MAXD: f32 = 72.0;
const DAY_LEN: f32 = 300.0;
const FOV: f32 = 1.3;
const EYE: f32 = 1.62;
const PW: f32 = 0.3; // половина ширины игрока
const PH: f32 = 1.8; // рост игрока

const AIR: u8 = 0;
const GRASS: u8 = 1;
const DIRT: u8 = 2;
const STONE: u8 = 3;
const SAND: u8 = 4;
const WOOD: u8 = 5;
const LEAVES: u8 = 6;
const PLANKS: u8 = 7;
const GLOW: u8 = 8;
const WATER: u8 = 9;

const HOTBAR: [u8; 8] = [DIRT, STONE, SAND, WOOD, PLANKS, LEAVES, GLOW, GRASS];
const HOTBAR_NAMES: [&str; 8] = [
    "Земля", "Камень", "Песок", "Бревно", "Доски", "Листва", "Лампа", "Трава",
];

type V3 = [f32; 3];

// ---------------------------------------------------------------- утилиты

fn hash(a: i32, b: i32, c: i32) -> u32 {
    let mut x = (a as u32).wrapping_mul(0x9E37_79B1)
        ^ (b as u32).wrapping_mul(0x85EB_CA6B)
        ^ (c as u32).wrapping_mul(0xC2B2_AE35);
    x ^= x >> 15;
    x = x.wrapping_mul(0x2C1B_3C6D);
    x ^= x >> 12;
    x = x.wrapping_mul(0x297A_2D39);
    x ^= x >> 15;
    x
}

fn rnd(a: i32, b: i32, c: i32) -> f32 {
    (hash(a, b, c) >> 8) as f32 / 16_777_216.0
}

fn vnoise(x: f32, z: f32, seed: i32) -> f32 {
    let xi = x.floor();
    let zi = z.floor();
    let fx = x - xi;
    let fz = z - zi;
    let sx = fx * fx * (3.0 - 2.0 * fx);
    let sz = fz * fz * (3.0 - 2.0 * fz);
    let (x0, z0) = (xi as i32, zi as i32);
    let a = rnd(x0, z0, seed);
    let b = rnd(x0 + 1, z0, seed);
    let c = rnd(x0, z0 + 1, seed);
    let d = rnd(x0 + 1, z0 + 1, seed);
    let top = a + (b - a) * sx;
    let bot = c + (d - c) * sx;
    top + (bot - top) * sz
}

fn fbm(x: f32, z: f32, seed: i32) -> f32 {
    let (mut amp, mut f, mut s, mut norm) = (0.5f32, 1.0f32, 0.0f32, 0.0f32);
    for o in 0..4 {
        s += amp * vnoise(x * f, z * f, seed + o);
        norm += amp;
        amp *= 0.5;
        f *= 2.0;
    }
    s / norm
}

fn mix3(a: V3, b: V3, t: f32) -> V3 {
    [
        a[0] + (b[0] - a[0]) * t,
        a[1] + (b[1] - a[1]) * t,
        a[2] + (b[2] - a[2]) * t,
    ]
}

fn norm(v: V3) -> V3 {
    let l = (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt();
    [v[0] / l, v[1] / l, v[2] / l]
}

fn dot(a: V3, b: V3) -> f32 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn smooth(e0: f32, e1: f32, x: f32) -> f32 {
    let t = ((x - e0) / (e1 - e0)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

// ---------------------------------------------------------------- мир

struct Hit {
    cell: [i32; 3],
    prev: [i32; 3],
    axis: usize,
    sgn: i32,
    t: f32,
}

struct World {
    b: Vec<u8>,
    light: Vec<u8>,
}

impl World {
    fn idx(x: usize, y: usize, z: usize) -> usize {
        (y * SZ + z) * SX + x
    }

    fn inb(x: i32, y: i32, z: i32) -> bool {
        x >= 0 && y >= 0 && z >= 0 && x < SX as i32 && y < SY as i32 && z < SZ as i32
    }

    fn get(&self, x: i32, y: i32, z: i32) -> u8 {
        if !Self::inb(x, y, z) {
            return AIR;
        }
        self.b[Self::idx(x as usize, y as usize, z as usize)]
    }

    fn set(&mut self, x: i32, y: i32, z: i32, v: u8) {
        if Self::inb(x, y, z) {
            let i = Self::idx(x as usize, y as usize, z as usize);
            self.b[i] = v;
        }
    }

    fn solid(&self, x: i32, y: i32, z: i32) -> bool {
        if y < 0 {
            return true;
        }
        if y >= SY as i32 {
            return false;
        }
        if x < 0 || z < 0 || x >= SX as i32 || z >= SZ as i32 {
            return true;
        }
        let b = self.get(x, y, z);
        b != AIR && b != WATER
    }

    fn light_at(&self, c: [i32; 3]) -> u8 {
        if !Self::inb(c[0], c[1], c[2]) {
            return 0;
        }
        self.light[Self::idx(c[0] as usize, c[1] as usize, c[2] as usize)]
    }

    fn relight(&mut self) {
        for l in self.light.iter_mut() {
            *l = 0;
        }
        let mut q = VecDeque::new();
        for y in 0..SY {
            for z in 0..SZ {
                for x in 0..SX {
                    let i = Self::idx(x, y, z);
                    if self.b[i] == GLOW {
                        self.light[i] = 14;
                        q.push_back((x as i32, y as i32, z as i32));
                    }
                }
            }
        }
        let dirs = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)];
        while let Some((x, y, z)) = q.pop_front() {
            let l = self.light[Self::idx(x as usize, y as usize, z as usize)];
            if l <= 1 {
                continue;
            }
            for (dx, dy, dz) in dirs {
                let (nx, ny, nz) = (x + dx, y + dy, z + dz);
                if !Self::inb(nx, ny, nz) || self.solid(nx, ny, nz) {
                    continue;
                }
                let ni = Self::idx(nx as usize, ny as usize, nz as usize);
                if self.light[ni] + 1 < l {
                    self.light[ni] = l - 1;
                    q.push_back((nx, ny, nz));
                }
            }
        }
    }

    fn generate(seed: i32) -> World {
        let mut w = World { b: vec![AIR; SX * SY * SZ], light: vec![0; SX * SY * SZ] };
        let mut heights = vec![0i32; SX * SZ];
        for z in 0..SZ {
            for x in 0..SX {
                let n = fbm(x as f32 * 0.035, z as f32 * 0.035, seed);
                let h = (9.0 + (n - 0.4) * 44.0).clamp(2.0, 30.0) as i32;
                heights[z * SX + x] = h;
                let beach = h <= SEA + 1;
                for y in 0..=h {
                    let b = if y == h {
                        if beach { SAND } else { GRASS }
                    } else if y >= h - 3 {
                        if beach { SAND } else { DIRT }
                    } else {
                        STONE
                    };
                    w.set(x as i32, y, z as i32, b);
                }
                for y in (h + 1)..=SEA {
                    w.set(x as i32, y, z as i32, WATER);
                }
            }
        }
        // деревья
        for z in 3..(SZ as i32 - 3) {
            for x in 3..(SX as i32 - 3) {
                let h = heights[z as usize * SX + x as usize];
                if w.get(x, h, z) == GRASS && rnd(x, z, seed + 99) < 0.012 {
                    let th = 4 + (hash(x, z, seed + 7) % 2) as i32;
                    for dy in 1..=th {
                        w.set(x, h + dy, z, WOOD);
                    }
                    for dy in (th - 1)..=(th + 1) {
                        let r: i32 = if dy == th + 1 { 1 } else { 2 };
                        for dx in -r..=r {
                            for dz in -r..=r {
                                if r == 2 && dx.abs() == 2 && dz.abs() == 2 {
                                    continue;
                                }
                                if dx == 0 && dz == 0 && dy <= th {
                                    continue;
                                }
                                if w.get(x + dx, h + dy, z + dz) == AIR {
                                    w.set(x + dx, h + dy, z + dz, LEAVES);
                                }
                            }
                        }
                    }
                }
            }
        }
        w.relight();
        w
    }

    fn surface_y(&self, x: i32, z: i32) -> i32 {
        let mut y = SY as i32 - 1;
        while y > 0 && (self.get(x, y, z) == AIR || self.get(x, y, z) == WATER) {
            y -= 1;
        }
        y + 1
    }

    fn spawn(&self) -> V3 {
        let (cx, cz) = (SX as i32 / 2, SZ as i32 / 2);
        let mut best = (i32::MAX, cx, cz);
        for z in 4..(SZ as i32 - 4) {
            for x in 4..(SX as i32 - 4) {
                let y = self.surface_y(x, z);
                if y > SEA + 2 {
                    let d = (x - cx) * (x - cx) + (z - cz) * (z - cz);
                    if d < best.0 {
                        best = (d, x, z);
                    }
                }
            }
        }
        let y = self.surface_y(best.1, best.2);
        [best.1 as f32 + 0.5, y as f32 + 0.05, best.2 as f32 + 0.5]
    }

    // Обход вокселей (Amanatides–Woo). Возвращает попадание и длину пути внутри воды.
    fn cast(&self, o: V3, d: V3, maxd: f32) -> (Option<Hit>, f32) {
        let mut cell = [o[0].floor() as i32, o[1].floor() as i32, o[2].floor() as i32];
        let mut step = [0i32; 3];
        let mut tmax = [f32::INFINITY; 3];
        let mut tdelta = [f32::INFINITY; 3];
        for i in 0..3 {
            if d[i] > 0.0 {
                step[i] = 1;
                tdelta[i] = 1.0 / d[i];
                tmax[i] = ((cell[i] as f32 + 1.0) - o[i]) / d[i];
            } else if d[i] < 0.0 {
                step[i] = -1;
                tdelta[i] = -1.0 / d[i];
                tmax[i] = (o[i] - cell[i] as f32) / (-d[i]);
            }
        }
        let mut t = 0.0f32;
        let mut water = 0.0f32;
        let mut in_water = self.get(cell[0], cell[1], cell[2]) == WATER;
        loop {
            let a = if tmax[0] < tmax[1] {
                if tmax[0] < tmax[2] { 0 } else { 2 }
            } else if tmax[1] < tmax[2] {
                1
            } else {
                2
            };
            let tn = tmax[a];
            if tn > maxd {
                if in_water {
                    water += maxd - t;
                }
                return (None, water);
            }
            if in_water {
                water += tn - t;
            }
            t = tn;
            let prev = cell;
            cell[a] += step[a];
            tmax[a] += tdelta[a];
            if !Self::inb(cell[0], cell[1], cell[2]) {
                return (None, water);
            }
            let b = self.get(cell[0], cell[1], cell[2]);
            if b == AIR {
                in_water = false;
                continue;
            }
            if b == WATER {
                in_water = true;
                continue;
            }
            return (Some(Hit { cell, prev, axis: a, sgn: step[a], t }), water);
        }
    }
}

// ---------------------------------------------------------------- текстуры и небо

fn tex(b: u8, face: u8, tx: i32, ty: i32) -> V3 {
    // face: 0 = верх, 1 = низ, 2 = бок; ty: 0 = низ грани, 7 = верх грани
    let n = rnd(tx + b as i32 * 17, ty + face as i32 * 5, 31);
    let g = 0.86 + 0.28 * n;
    let sc = |c: V3, k: f32| [c[0] * k, c[1] * k, c[2] * k];
    match b {
        GRASS => match face {
            0 => sc([80.0, 158.0, 58.0], g),
            1 => sc([121.0, 85.0, 58.0], g),
            _ => {
                if ty >= 6 {
                    sc([80.0, 158.0, 58.0], g)
                } else {
                    sc([121.0, 85.0, 58.0], g)
                }
            }
        },
        DIRT => sc([121.0, 85.0, 58.0], g),
        STONE => {
            let k = 0.8 + 0.4 * n;
            let k = if n > 0.93 { k * 0.7 } else { k };
            sc([124.0, 124.0, 128.0], k)
        }
        SAND => sc([218.0, 205.0, 150.0], 0.93 + 0.14 * n),
        WOOD => {
            if face < 2 {
                let r = ((tx as f32 - 3.5).abs()).max((ty as f32 - 3.5).abs()) as i32;
                if r % 2 == 0 {
                    sc([150.0, 115.0, 70.0], g)
                } else {
                    sc([120.0, 88.0, 50.0], g)
                }
            } else if tx % 3 == 0 {
                sc([88.0, 62.0, 34.0], g)
            } else {
                sc([104.0, 76.0, 42.0], g)
            }
        }
        LEAVES => {
            if n < 0.2 {
                sc([30.0, 80.0, 30.0], 1.0)
            } else {
                sc([56.0, 128.0, 48.0], g)
            }
        }
        PLANKS => {
            if ty % 4 == 0 {
                sc([130.0, 95.0, 55.0], g)
            } else {
                sc([172.0, 134.0, 82.0], g)
            }
        }
        GLOW => {
            if tx == 0 || ty == 0 {
                [225.0, 180.0, 90.0]
            } else {
                sc([255.0, 228.0, 140.0], 0.9 + 0.2 * n)
            }
        }
        _ => [255.0, 0.0, 255.0],
    }
}

fn sky(d: V3, sun: V3, day: f32) -> V3 {
    let t = d[1].clamp(0.0, 1.0).sqrt();
    let dh = [170.0, 205.0, 245.0];
    let dz = [70.0, 120.0, 220.0];
    let nh = [18.0, 24.0, 50.0];
    let nz = [4.0, 6.0, 20.0];
    let h = mix3(nh, dh, day);
    let z = mix3(nz, dz, day);
    let mut c = mix3(h, z, t);
    let dusk = (1.0 - (day - 0.4).abs() / 0.4).clamp(0.0, 1.0);
    c = mix3(c, [255.0, 140.0, 70.0], dusk * (1.0 - t) * 0.45);
    let ds = dot(d, sun);
    if ds > 0.9985 {
        c = [255.0, 245.0, 205.0];
    } else if ds > 0.99 {
        let k = (ds - 0.99) / 0.0085;
        c = mix3(c, [255.0, 235.0, 180.0], k * k * 0.5);
    }
    if -ds > 0.9993 {
        c = [225.0, 230.0, 242.0];
    }
    if day < 0.35 && d[1] > 0.0 {
        let q = [(d[0] * 80.0).floor() as i32, (d[1] * 80.0).floor() as i32, (d[2] * 80.0).floor() as i32];
        if rnd(q[0], q[1], q[2]) < 0.0025 {
            let k = (0.35 - day) / 0.35;
            c = mix3(c, [255.0, 255.0, 255.0], k);
        }
    }
    c
}

// ---------------------------------------------------------------- игра

#[derive(Default)]
struct Keys {
    fwd: f32,
    back: f32,
    left: f32,
    right: f32,
    up: f32,
    down: f32,
}

struct Game {
    world: World,
    pos: V3,
    vel: V3,
    yaw: f32,
    pitch: f32,
    on_ground: bool,
    fly: bool,
    time: f32,
    sel: usize,
    keys: Keys,
    spawn: V3,
}

impl Game {
    fn new() -> Game {
        let world = World::generate(1337);
        let spawn = world.spawn();
        Game {
            world,
            pos: spawn,
            vel: [0.0; 3],
            yaw: 0.6,
            pitch: -0.15,
            on_ground: false,
            fly: false,
            time: DAY_LEN * 0.12,
            sel: 0,
            keys: Keys::default(),
            spawn,
        }
    }

    fn eye(&self) -> V3 {
        [self.pos[0], self.pos[1] + EYE, self.pos[2]]
    }

    fn look_dir(&self) -> V3 {
        let (sy, cy) = (self.yaw.sin(), self.yaw.cos());
        let (sp, cp) = (self.pitch.sin(), self.pitch.cos());
        [sy * cp, sp, cy * cp]
    }

    fn blocked(&self, p: V3) -> bool {
        let e = 0.001;
        let x0 = (p[0] - PW).floor() as i32;
        let x1 = (p[0] + PW - e).floor() as i32;
        let y0 = p[1].floor() as i32;
        let y1 = (p[1] + PH - e).floor() as i32;
        let z0 = (p[2] - PW).floor() as i32;
        let z1 = (p[2] + PW - e).floor() as i32;
        for y in y0..=y1 {
            for z in z0..=z1 {
                for x in x0..=x1 {
                    if self.world.solid(x, y, z) {
                        return true;
                    }
                }
            }
        }
        false
    }

    fn update(&mut self, dt: f32) {
        self.time += dt;
        for k in [
            &mut self.keys.fwd,
            &mut self.keys.back,
            &mut self.keys.left,
            &mut self.keys.right,
            &mut self.keys.up,
            &mut self.keys.down,
        ] {
            *k = (*k - dt).max(0.0);
        }
        let (sy, cy) = (self.yaw.sin(), self.yaw.cos());
        let mvf = (self.keys.fwd > 0.0) as i32 as f32 - (self.keys.back > 0.0) as i32 as f32;
        let mvs = (self.keys.right > 0.0) as i32 as f32 - (self.keys.left > 0.0) as i32 as f32;
        let mut wx = sy * mvf + cy * mvs;
        let mut wz = cy * mvf - sy * mvs;
        let l = (wx * wx + wz * wz).sqrt();
        if l > 1.0 {
            wx /= l;
            wz /= l;
        }
        let speed = if self.fly { 11.0 } else { 4.6 };
        self.vel[0] = wx * speed;
        self.vel[2] = wz * speed;
        if self.fly {
            self.vel[1] = ((self.keys.up > 0.0) as i32 - (self.keys.down > 0.0) as i32) as f32 * 7.0;
        } else {
            self.vel[1] = (self.vel[1] - 28.0 * dt).max(-50.0);
        }
        let steps = (dt / 0.01).ceil().max(1.0) as i32;
        let sdt = dt / steps as f32;
        let mut hit_wall = false;
        for _ in 0..steps {
            for a in 0..3 {
                let mut np = self.pos;
                np[a] += self.vel[a] * sdt;
                if !self.blocked(np) {
                    self.pos = np;
                } else if a == 1 {
                    self.vel[1] = 0.0;
                } else if self.vel[a].abs() > 0.01 {
                    hit_wall = true;
                }
            }
        }
        let below = [self.pos[0], self.pos[1] - 0.03, self.pos[2]];
        self.on_ground = self.blocked(below);
        if hit_wall && self.on_ground && !self.fly {
            self.vel[1] = 8.6; // авто-прыжок через ступеньку
        }
        if self.pos[1] < -10.0 {
            self.pos = self.spawn;
            self.vel = [0.0; 3];
        }
    }

    fn jump(&mut self) {
        if self.fly {
            self.keys.up = 0.25;
        } else if self.on_ground {
            self.vel[1] = 8.6;
        }
    }

    fn break_block(&mut self) {
        let (h, _) = self.world.cast(self.eye(), self.look_dir(), 6.0);
        if let Some(h) = h {
            let [x, y, z] = h.cell;
            if y > 0 {
                let old = self.world.get(x, y, z);
                self.world.set(x, y, z, AIR);
                if old == GLOW {
                    self.world.relight();
                }
            }
        }
    }

    fn place_block(&mut self) {
        let (h, _) = self.world.cast(self.eye(), self.look_dir(), 6.0);
        if let Some(h) = h {
            let [x, y, z] = h.prev;
            let old = self.world.get(x, y, z);
            if World::inb(x, y, z) && (old == AIR || old == WATER) {
                let b = HOTBAR[self.sel];
                self.world.set(x, y, z, b);
                if self.blocked(self.pos) {
                    self.world.set(x, y, z, old);
                } else if b == GLOW {
                    self.world.relight();
                }
            }
        }
    }

    fn render(&self, pw: usize, ph: usize) -> Vec<[u8; 3]> {
        let a = self.time / DAY_LEN * TAU;
        let sunh = a.sin();
        let day = smooth(-0.12, 0.22, sunh);
        let sun = norm([0.35, sunh, a.cos() * 0.9]);
        let amb = 0.16 + 0.84 * day;
        let cool = 1.0 - day;
        let o = self.eye();
        let (sy, cy) = (self.yaw.sin(), self.yaw.cos());
        let (sp, cp) = (self.pitch.sin(), self.pitch.cos());
        let fwd = [sy * cp, sp, cy * cp];
        let right = [cy, 0.0, -sy];
        let up = [-sp * sy, cp, -sp * cy];
        let tanh = (FOV * 0.5).tan();
        let asp = pw as f32 / ph as f32;
        let mut out = vec![[0u8; 3]; pw * ph];
        for j in 0..ph {
            let v = (1.0 - 2.0 * (j as f32 + 0.5) / ph as f32) * tanh;
            for i in 0..pw {
                let u = (2.0 * (i as f32 + 0.5) / pw as f32 - 1.0) * tanh * asp;
                let d = norm([
                    fwd[0] + right[0] * u + up[0] * v,
                    fwd[1] + right[1] * u + up[1] * v,
                    fwd[2] + right[2] * u + up[2] * v,
                ]);
                let (hit, wlen) = self.world.cast(o, d, MAXD);
                let mut col = match hit {
                    None => sky(d, sun, day),
                    Some(h) => {
                        let p = [o[0] + d[0] * h.t, o[1] + d[1] * h.t, o[2] + d[2] * h.t];
                        let (face, uu, vv) = match h.axis {
                            0 => (2u8, p[2], p[1]),
                            1 => (if h.sgn < 0 { 0u8 } else { 1u8 }, p[0], p[2]),
                            _ => (2u8, p[0], p[1]),
                        };
                        let tx = ((uu.rem_euclid(1.0) * 8.0) as i32).clamp(0, 7);
                        let ty = ((vv.rem_euclid(1.0) * 8.0) as i32).clamp(0, 7);
                        let blk = self.world.get(h.cell[0], h.cell[1], h.cell[2]);
                        let base = tex(blk, face, tx, ty);
                        let c = if blk == GLOW {
                            base
                        } else {
                            let fs = match (h.axis, h.sgn) {
                                (1, -1) => 1.0,
                                (1, _) => 0.55,
                                (0, _) => 0.82,
                                _ => 0.7,
                            };
                            let cellv = 0.96 + 0.08 * rnd(h.cell[0], h.cell[1], h.cell[2]);
                            let l = self.world.light_at(h.prev) as f32 / 14.0;
                            let lf = l.powf(1.4);
                            let shade = amb.max(lf * 0.95) * fs * cellv;
                            let warm = (lf * (1.0 - day * 0.8)).min(1.0);
                            let tint0 = [1.0 - 0.18 * cool, 1.0 - 0.08 * cool, 1.0 + 0.12 * cool];
                            let tint = mix3(tint0, [1.0, 0.82, 0.55], warm);
                            [base[0] * shade * tint[0], base[1] * shade * tint[1], base[2] * shade * tint[2]]
                        };
                        let f = (h.t / MAXD).powi(2).min(1.0);
                        mix3(c, sky(d, sun, day), f)
                    }
                };
                if wlen > 0.0 {
                    let k = (1.0 - (-wlen * 0.3).exp()) * 0.85;
                    let wc = [5.0 + 25.0 * day, 15.0 + 60.0 * day, 30.0 + 130.0 * day];
                    col = mix3(col, wc, k);
                }
                out[j * pw + i] = [
                    col[0].clamp(0.0, 255.0) as u8,
                    col[1].clamp(0.0, 255.0) as u8,
                    col[2].clamp(0.0, 255.0) as u8,
                ];
            }
        }
        out
    }
}

// ---------------------------------------------------------------- терминал

fn stty(args: &[&str]) -> String {
    Command::new("stty")
        .args(args)
        .stdin(Stdio::inherit())
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

fn term_size() -> (usize, usize) {
    let s = stty(&["size"]);
    let mut it = s.split_whitespace();
    let rows = it.next().and_then(|x| x.parse().ok()).unwrap_or(24);
    let cols = it.next().and_then(|x| x.parse().ok()).unwrap_or(80);
    (cols, rows)
}

struct Term {
    saved: String,
}

impl Term {
    fn enter() -> Term {
        let saved = stty(&["-g"]);
        stty(&["raw", "-echo"]);
        print!("\x1b[?1049h\x1b[?25l\x1b[2J");
        let _ = io::stdout().flush();
        Term { saved }
    }
}

impl Drop for Term {
    fn drop(&mut self) {
        if !self.saved.is_empty() {
            stty(&[self.saved.as_str()]);
        } else {
            stty(&["sane"]);
        }
        print!("\x1b[0m\x1b[?25h\x1b[?1049l");
        let _ = io::stdout().flush();
    }
}

fn run() {
    let (tx, rx) = mpsc::channel::<u8>();
    thread::spawn(move || {
        let mut si = io::stdin();
        let mut buf = [0u8; 1];
        loop {
            match si.read(&mut buf) {
                Ok(1) => {
                    if tx.send(buf[0]).is_err() {
                        break;
                    }
                }
                _ => break,
            }
        }
    });

    let mut game = Game::new();
    let _term = Term::enter();
    let (mut cols, mut rows) = term_size();
    let mut esc = 0u8;
    let mut frame_no = 0u64;
    let mut last = Instant::now();
    let mut fps = 0.0f32;
    let target = Duration::from_millis(50);
    let look = 0.09f32;

    'main: loop {
        let t0 = Instant::now();
        while let Ok(b) = rx.try_recv() {
            match esc {
                1 => {
                    esc = if b == b'[' { 2 } else { 0 };
                    continue;
                }
                2 => {
                    match b {
                        b'A' => game.pitch = (game.pitch + look).min(1.5),
                        b'B' => game.pitch = (game.pitch - look).max(-1.5),
                        b'C' => game.yaw += look,
                        b'D' => game.yaw -= look,
                        b'0'..=b'9' | b';' => continue,
                        _ => {}
                    }
                    esc = 0;
                    continue;
                }
                _ => {}
            }
            match b {
                0x1b => esc = 1,
                3 | b'q' | b'Q' => break 'main,
                b'w' | b'W' => {
                    game.keys.fwd = 0.25;
                    game.keys.back = 0.0;
                }
                b's' | b'S' => {
                    game.keys.back = 0.25;
                    game.keys.fwd = 0.0;
                }
                b'a' | b'A' => {
                    game.keys.left = 0.25;
                    game.keys.right = 0.0;
                }
                b'd' | b'D' => {
                    game.keys.right = 0.25;
                    game.keys.left = 0.0;
                }
                b' ' => game.jump(),
                b'z' | b'Z' => game.keys.down = 0.25,
                b'j' | b'J' => game.yaw -= look,
                b'l' | b'L' => game.yaw += look,
                b'i' | b'I' => game.pitch = (game.pitch + look).min(1.5),
                b'k' | b'K' => game.pitch = (game.pitch - look).max(-1.5),
                b'x' | b'X' => game.break_block(),
                b'c' | b'C' => game.place_block(),
                b'f' | b'F' => game.fly = !game.fly,
                b't' | b'T' => game.time += 25.0,
                b'1'..=b'8' => game.sel = (b - b'1') as usize,
                _ => {}
            }
        }

        let now = Instant::now();
        let dt = now.duration_since(last).as_secs_f32().min(0.1);
        last = now;
        game.update(dt);

        if frame_no % 40 == 0 {
            let s = term_size();
            cols = s.0;
            rows = s.1;
        }
        let w = cols.clamp(20, 220);
        let hrows = rows.saturating_sub(2).clamp(6, 70);
        let h = hrows * 2;
        let mut px = game.render(w, h);
        // прицел
        let (cx, cy) = (w / 2, h / 2);
        for k in 1..=2usize {
            for &(ox, oy) in &[(k as i32, 0), (-(k as i32), 0), (0, k as i32), (0, -(k as i32))] {
                let x = (cx as i32 + ox) as usize;
                let y = (cy as i32 + oy) as usize;
                let p = &mut px[y * w + x];
                *p = [255 - p[0], 255 - p[1], 255 - p[2]];
            }
        }

        let mut out = String::with_capacity(w * hrows * 12);
        out.push_str("\x1b[H");
        for r in 0..hrows {
            let _ = write!(out, "\x1b[{};1H", r + 1);
            let mut lastc = ([255u8; 3], [255u8; 3]);
            let mut first = true;
            for c in 0..w {
                let t = px[(2 * r) * w + c];
                let b = px[(2 * r + 1) * w + c];
                if first || (t, b) != lastc {
                    let _ = write!(
                        out,
                        "\x1b[38;2;{};{};{};48;2;{};{};{}m",
                        t[0], t[1], t[2], b[0], b[1], b[2]
                    );
                    lastc = (t, b);
                    first = false;
                }
                out.push('▀');
            }
        }
        // HUD
        let _ = write!(out, "\x1b[{};1H\x1b[0m\x1b[K", hrows + 1);
        for i in 0..8 {
            if i == game.sel {
                let _ = write!(out, "\x1b[7m[{}]{}\x1b[0m ", i + 1, HOTBAR_NAMES[i]);
            } else {
                let _ = write!(out, "[{}]{} ", i + 1, HOTBAR_NAMES[i]);
            }
        }
        let a = game.time / DAY_LEN * TAU;
        let _ = write!(
            out,
            "\x1b[{};1H\x1b[0m\x1b[K x:{:.1} y:{:.1} z:{:.1}  {}  {}  {:.0} fps | WASD ходьба, стрелки/IJKL обзор, пробел прыжок, X ломать, C ставить, F полёт, T время, Q выход",
            hrows + 2,
            game.pos[0],
            game.pos[1],
            game.pos[2],
            if a.sin() > 0.0 { "день" } else { "ночь" },
            if game.fly { "полёт" } else { "земля" },
            fps
        );
        let so = io::stdout();
        let mut lock = so.lock();
        let _ = lock.write_all(out.as_bytes());
        let _ = lock.flush();
        drop(lock);

        frame_no += 1;
        let el = t0.elapsed();
        fps = fps * 0.9 + 0.1 * (1.0 / el.max(target).as_secs_f32());
        if el < target {
            thread::sleep(target - el);
        }
    }
}

fn snapshot(path: &str, yaw: f32, pitch: f32, tfrac: f32) {
    let mut g = Game::new();
    g.yaw = yaw;
    g.pitch = pitch;
    g.time = DAY_LEN * tfrac;
    let (w, h) = (640usize, 360usize);
    let px = g.render(w, h);
    let mut data = format!("P6\n{} {}\n255\n", w, h).into_bytes();
    for p in px {
        data.extend_from_slice(&p);
    }
    std::fs::write(path, data).expect("не удалось записать файл");
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 3 && args[1] == "--snapshot" {
        let f = |i: usize, d: f32| args.get(i).and_then(|s| s.parse().ok()).unwrap_or(d);
        snapshot(&args[2], f(3, 0.6), f(4, -0.15), f(5, 0.12));
        return;
    }
    run();
}
